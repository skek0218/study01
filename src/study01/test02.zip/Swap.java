package study01.test02;

public class Swap 
{
	public static void main(String[] args)
	{
		/*int a = 5;
		int b = 3; 
		int c;
		c = a;
		a = b;
		b = c;
		System.out.println(a + "," + b);
		
		int[] nums = new int[3];
		nums[0] = 1;
		nums[1] = 3;
		nums[2] = 5;
		int[] tmpNums = nums;
		nums = new int[4];
		nums[0] = tmpNums[0];
		nums[1] = tmpNums[1];
		nums[2] = tmpNums[2];
		nums[3] = 7;
		System.out.println(nums[3]);*/
	}
}
