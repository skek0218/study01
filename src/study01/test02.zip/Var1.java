package study01.test02;

public class Var1 
{
	public static void main(String[] args)
	{
		int num = 1;
		
		for(;num < 10;num++)
		{
			System.out.println(num);
		}
		System.out.println(num);
	}
	
}
