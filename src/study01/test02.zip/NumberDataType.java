package study01.test02;

public class NumberDataType 
{
	public static void main(String[] args)
	{
		/*byte b = 127;
		short s = 128;
		int i = 1000000;
		long l = 1000000000;*/
		byte b = 1;
		short s = b;
		
		
		double d = 1;
		float f = 1.1f;
		System.out.println("");
	}
}
